package com.carnival.migration.core.service.component.impl;

import static org.apache.jackrabbit.JcrConstants.NT_UNSTRUCTURED;
import static org.apache.sling.jcr.resource.api.JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.AbstractResourceVisitor;
import org.apache.sling.api.resource.Resource;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.modernize.RewriteException;
import com.adobe.aem.modernize.component.ComponentRewriteRule;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

/**
 * @author class to convert secondaryNavigation(6.4) component to
 *         privacylegalnavigation(6.5) component
 *
 */
@Component
@Designate(ocd = SecondaryNavigationRewriteRule.SecondaryNavigationConfig.class)
public class SecondaryNavigationRewriteRule implements ComponentRewriteRule {

	private static final Logger log = LoggerFactory.getLogger(SecondaryNavigationRewriteRule.class);
	private SecondaryNavigationConfig config;
	private String oldResourceType;
	private String newResourceType;
	private Map<String, String> pathsToReplaceInURL;

	@Override
	public Set<String> findMatches(Resource resource) {
		final Set<String> paths = new HashSet<>();
		new AbstractResourceVisitor() {
			@Override
			protected void visit(Resource resource) {
				String resourceType = resource.getResourceType();
				if (!StringUtils.isEmpty(oldResourceType) && StringUtils.equals(oldResourceType, resourceType)) {
					paths.add(resource.getPath());
				}
			}
		}.accept(resource);
		return paths;
	}

	@Override
	public boolean hasPattern(String... slingResourceTypes) {
		List<String> types = Arrays.asList(slingResourceTypes);
		log.debug("hasPattern types = {}", types);
		return types.contains(oldResourceType);
	}

	@Override
	public String getId() {
		return SecondaryNavigationRewriteRule.class.getName();
	}

	@Override
	public boolean matches(Node node) throws RepositoryException {
		log.debug("match node path = {}", node.getPath());
		if (!node.hasProperty(SLING_RESOURCE_TYPE_PROPERTY)) {
			return false;
		}
		String propertyValue = StringUtils.EMPTY;
		if (node.hasProperty(SLING_RESOURCE_TYPE_PROPERTY)) {
			propertyValue = node.getProperty(SLING_RESOURCE_TYPE_PROPERTY).getString();
			log.debug("Node has resourceType : {}", propertyValue);
		}
		return propertyValue.contains(oldResourceType);
	}

	@Override
	public Node applyTo(Node root, Set<String> finalPaths) throws RewriteException, RepositoryException {
		log.debug("applTo node path = {}", root.getPath());
		return transform(root);
	}

	/**
	 * transorm 6.4 secondaryNavigation component to 6.5 privacylegalnavigation
	 * 
	 * @param root
	 * @return
	 */
	private Node transform(Node root) {
		try {
			root.setProperty(SLING_RESOURCE_TYPE_PROPERTY, newResourceType);
			final String SECONDARY_NAVIGATION_NODE_NAME = "secondaryNavigation";
			final String NAV_ITEMS_NODE_NAME = "navitems";
			final String LINKS_NODE_NAME = "links";
			final String ITEM_NODE_NAME = "item";
			final String PROPERTY_LABEL = "label";
			final String PROPERTY_PATH = "path";
			final String LINK_NODE_NAME = "link";
			final String PROPERTY_URL = "url";
			if (root.hasNode(SECONDARY_NAVIGATION_NODE_NAME)) {
				Node secondaryNavigation = root.getNode(SECONDARY_NAVIGATION_NODE_NAME);
				root.addNode(NAV_ITEMS_NODE_NAME, NT_UNSTRUCTURED);
				if (secondaryNavigation.hasNode(LINKS_NODE_NAME)) {
					Node links = secondaryNavigation.getNode(LINKS_NODE_NAME);
					Node navItems = root.getNode(NAV_ITEMS_NODE_NAME);
					if (links.hasNodes()) {
						NodeIterator items = links.getNodes();
						Gson gson = new Gson();
						while (items.hasNext()) {
							Node item = items.nextNode();
							Node navItemNode = navItems.addNode(ITEM_NODE_NAME + items.getPosition(), NT_UNSTRUCTURED);
							JsonObject json = gson.fromJson(item.getProperty(LINK_NODE_NAME).getString() != null
									? item.getProperty(LINK_NODE_NAME).getString()
									: "", JsonObject.class);
							navItemNode.setProperty(PROPERTY_LABEL, json.get(PROPERTY_LABEL).getAsString());
							navItemNode.setProperty(PROPERTY_PATH, modifyURLPath(json.get(PROPERTY_URL).getAsString()));
						}
						secondaryNavigation.remove();
					}
				}
			}
		} catch (JsonSyntaxException | RepositoryException e) {
			log.error("exception occured during trnsformation : ", e);
		}
		return root;
	}

	/**
	 * replaces source relative path with destination relative path , refers to
	 * pathsToReplaceInURL OSGI config
	 * 
	 * @param oldURLPath
	 * @return
	 */
	private String modifyURLPath(final String oldURLPath) {
		String url = oldURLPath;
		log.debug("map = {}", pathsToReplaceInURL);
		if (!StringUtils.isEmpty(url)) {
			Optional<Object> match = pathsToReplaceInURL.entrySet().stream()
					.filter(i -> oldURLPath.contains(i.getKey())).findFirst().map(Entry::getKey);
			if (match.isPresent()) {
				log.debug("previous navigation url = {}", url);
				url = url.replaceFirst(match.get().toString(), pathsToReplaceInURL.get(match.get().toString()));
				log.debug("updated navigation url = {}", url);
			}
		}
		return url;
	}

	@Activate
	@Modified
	protected void activate(SecondaryNavigationConfig config) {
		this.config = config;
		this.oldResourceType = config.oldResourceType();
		this.newResourceType = config.newResourceType();
		this.pathsToReplaceInURL = new HashMap<>();
		for (String urlString : config.pathsToReplaceInURL()) {
			log.debug("urlString = {}", urlString);
			if (!StringUtils.isEmpty(urlString) && urlString.contains(":")) {
				String[] paths = urlString.split(":");
				this.pathsToReplaceInURL.put(paths[0], paths[1]);
			}
		}
	}

	@ObjectClassDefinition(name = "Component Rewrite Rule Service for Secondary Navigation links", description = "AEM Modernize Tools - Config defination for Component Rewrite Rule Service for Secondary Navigation links")
	@interface SecondaryNavigationConfig {
		@AttributeDefinition(name = "OLD Resource Type for Secondary Navigation ", description = "Resource Type path for old secondary navigation component")
		String oldResourceType();

		@AttributeDefinition(name = "NEW Resource Type for Secondary Navigation ", description = "Resource Type path for new secondary navigation component")
		String newResourceType();

		@AttributeDefinition(name = "Relative Path to replace in URLs ", description = "Relative Path to replace in old URLs : with new relative path")
		String[] pathsToReplaceInURL();
	}
}
