import javax.jcr.Node


// path of faqs root page where all faq child pages reside in old content
source_page_path = '/content/hal/master_content/en_US/faqs'
// path of accordian node where all faq nodes to be created
destination_faqs_root_node = '/content/hal/global/en/authoring-guide/faq_migrate/jcr:content/root/container/faqsearch_copy_599030454/accordion'
// resource type of faq component in old content 
source_faqs_resource_type = 'carnival/platform/components/mcm/faqs'

// search for pages based on resource type
def buildQuery(page, term) {
	def queryManager = session.workspace.queryManager;
	def statement = 'select * from nt:base where jcr:path like \''+page.path+'/%\' and sling:resourceType = \'' + term + '\'';
	queryManager.createQuery(statement, 'sql');
}

final def sourcepage = getPage(source_page_path)
 
final def read_faq_nodes_query = buildQuery(sourcepage,source_faqs_resource_type)

final def result = read_faq_nodes_query.execute()

count = 0;

def destination_root_node = getNode(destination_faqs_root_node)

result.nodes.each { node ->

    String question = node.get('txQuestion');
    String answer = node.get('txAnswerCopy');
    
    def question_node = destination_root_node.addNode('item_'+count);
    question_node.set('sling:resourceType','hal/components/content/container')
    question_node.set('cq:panelTitle',question);
    question_node.set('text','true')
    
    def answer_node = question_node.addNode('text');
    answer_node.set('sling:resourceType','hal/components/content/text')
    answer_node.set('text',answer);
    answer_node.set('textIsRich','true')

	session.save()
    count++;
}

println " total faq nodes "+count