import groovy.json.*
import javax.jcr.Node;
import javax.jcr.PropertyIterator;

// Script to add Long description , Short description and HERO Image URL to Ships,Rooms & Sub-Room pages by reading properties from old content

// Root Path of pages to run the migration

source_page_path = "/content/sbn/global/en/cruise-ships"

// List of templates to consider for migration
ship_details_template = "/conf/sbn/settings/wcm/templates/ship-details-template"
ship_room_page_template = "/conf/sbn/settings/wcm/templates/ship-room-page-template"
ship_sub_room_page_template = "/conf/sbn/settings/wcm/templates/ship-sub-room-page-template"
blank_page_template = "/conf/sbn/settings/wcm/templates/blank-page-template"


list_of_templates = [ship_details_template, ship_room_page_template, ship_sub_room_page_template, blank_page_template]

// JCR property names declarations old - 6.4 site and new 6.5 site

old_hero_image_property_name = ""
old_long_description_property_name = ""
old_short_description_property_name = ""
new_hero_image_property_name = ""
new_long_description_property_name = ""
new_short_description_property_name = ""
master_data_child_node_name = ""


// counter variables
// counter for to count overall pages traversed during the migration
no_of_source_pages = 0

updateAllSourcePages()

def updateAllSourcePages() {
    getPage(source_page_path).recurse { page ->
        println "------------------- START -------------------------"
        println "Curent Page Path = " + page.path
        def source_page_content_node = page.node
        current_page_template = source_page_content_node.get("cq:template")
        println "Curent Page Template = " + current_page_template
        if (list_of_templates.contains(current_page_template)) {
            switch (current_page_template) {
                case ship_details_template:
                    setShipDetails(page)
                    break
                case ship_room_page_template:
                    setRoomDetails(page)
                    break
                case ship_sub_room_page_template:
                    setSubRoomDetails(page)
                    break
                case blank_page_template:
                    if (page.name == "deck") {
                        println "This is a Deck Page"
                        setDecksDetails(page)
                    } else {
                        println "This Blank Template page is not a Deck Page"
                    }
                    break
                default:
                    println "template not matched in switch case"
                    break
            }
            session.save()
        } else {
            println "Template doesn't match with the defined list"
        }
        println "------------------- END -------------------------"
        no_of_source_pages++
    }

}


// this method fetches 6.4 website content path using the legacy URL property in 6.5 content page
def getMasterWebSitePagePath(legacy_full_url) {
    def master_content_root_path = "/content/sbn/master_website"
    legacy_full_url = legacy_full_url.replace("comm","com")
    def master_website_page_path = legacy_full_url.replace("https://www.seabourn.com", "")
    master_website_page_path = master_website_page_path.replace(".html", "")
    master_website_page_path = master_content_root_path + master_website_page_path
    return master_website_page_path
}

// this method sets hero image property on the 6.5 site page
def setHeroImageURL(source_page_content_node, master_data_content) {
    def hero_image_url = ""
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        hero_image_url = child_node.get(old_hero_image_property_name)
        source_page_content_node.set(new_hero_image_property_name, hero_image_url)
        if (source_page_content_node.hasNode("root/container/hero")) {
            hero_node = source_page_content_node.getNode("root/container/hero")
            hero_node.set("heroType", "port")
        }
    }
    println "Hero Image URL in old content = " + hero_image_url

}

// this method sets short description  property on the 6.5 site page
def setShortDescritpion(source_page_content_node, master_data_content) {
    def short_description = ""
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        short_description = child_node.get("txShortDescription")
        source_page_content_node.set("shortDescription", short_description)
    }
    println "Short Description in old content = " + short_description

}

// this method sets long description  property on the 6.5 site page
def setLongDescription(source_page_content_node, master_data_content) {
    def long_description = ""
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        long_description = child_node.get(old_long_description_property_name)
        source_page_content_node.set(new_long_description_property_name, long_description)
    }
    println "Long Description in old content = " + long_description

}

def setPDFDeckImages(source_page_content_node, master_data_content) {
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        def all_decks_pdf = ""
        def accessibility_routes_pdf = ""
        if (child_node.hasNode("decksPdf")) {
            def decksPdf_node = child_node.getNode("decksPdf")
            decksPdf_node.recurse { childnode ->
                if (null != childnode.get("deckPdf")) {
                    deck_pdf_property = childnode.get("deckPdf")
                    def parser = new JsonSlurper()
                    def json = parser.parseText(deck_pdf_property)
                    if ("PDF All Decks" == json.label) {
                        all_decks_pdf = json.url
                        source_page_content_node.set("pdfalldecks", all_decks_pdf)
                    }
                    if ("Accessibility Routes (PDF)" == json.label) {
                        accessibility_routes_pdf = json.url
                        source_page_content_node.set("accessibilityRoutes", accessibility_routes_pdf)
                    }

                }
            }
            println "PDF All Decks = " + all_decks_pdf
            println "Accessibility Routes (PDF) = " + accessibility_routes_pdf
        }
        long_description = child_node.get(old_long_description_property_name)
        source_page_content_node.set(new_long_description_property_name, long_description)
    }
}




def setRoomCarousel(source_page_content_node, master_data_content) {
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        if (child_node.hasNode("roomCarouselDetails")) {
            def roomCarouselDetails_node_old = child_node.getNode("roomCarouselDetails")
            def no_of_carousel_images = 0
            roomCarouselDetails_node_old.recurse { item_node_old ->
                if (null != item_node_old.get("imageURL")) {
                    def section_image_and_json_node = null
                    if (!source_page_content_node.hasNode("sectionImageAndJson")) {
                        section_image_and_json_node = source_page_content_node.addNode("sectionImageAndJson")
                        println section_image_and_json_node.path
                    } else {
                        section_image_and_json_node = source_page_content_node.getNode("sectionImageAndJson")
                    }
                    def room_carousel_image_old = item_node_old.get("imageURL")
                    def item_node_name_new = "item" + no_of_carousel_images
                    def room_carousel_image = null
                    if(section_image_and_json_node.hasNode(item_node_name_new)){
                        room_carousel_image = section_image_and_json_node.getNode(item_node_name_new)
                    }else{
                        room_carousel_image = section_image_and_json_node.addNode(item_node_name_new)
                    }
                    room_carousel_image.set("roomImage", room_carousel_image_old)
                    println "Room Carousel Image " + no_of_carousel_images++ + " = " + room_carousel_image_old
                }
            }
        }
    }
}
// this method to set media gallery(images) present in 6.4 ship pages to image mutlified in 6.5 ship pages
def setMediaGallery(source_page_content_node, master_data_content) {
	if (master_data_content.hasNode(master_data_child_node_name)) {
		def child_node = master_data_content.getNode(master_data_child_node_name)
		if (child_node.hasNode("mediaGallery")) {
			def gallery_node = child_node.getNode("mediaGallery")
			if (null != gallery_node) {
				def no_of_images = 0
				if (!source_page_content_node.hasNode("image")) {
					ship_images_node = source_page_content_node.addNode("image")
					println ship_images_node.path
				} else {
					ship_images_node = source_page_content_node.getNode("image")
				}
				PropertyIterator propIter = gallery_node.getProperties();
				def imageValue=""
				while (propIter.hasNext()) {
					def item_node_name_new = "item" + no_of_images
					String property=propIter.nextProperty().getName()
					if (!property.startsWith("jcr:")) {
						imageValue= gallery_node.get(property);
						if(ship_images_node.hasNode(item_node_name_new)){
							ship_carousel_image = ship_images_node.getNode(item_node_name_new)
						}else{
							ship_carousel_image = ship_images_node.addNode(item_node_name_new)
						}
						ship_carousel_image.set("image", imageValue)
						println "Image " + no_of_images++ + " = " + imageValue
					}
				}
			}
		}
	}
}


def setSubRoomCarousel(source_page_content_node, master_data_content) {
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        if (child_node.hasNode("roomCarouselDetails")) {
            def roomCarouselDetails_node_old = child_node.getNode("roomCarouselDetails")
            def no_of_carousel_images = 0
            roomCarouselDetails_node_old.recurse { item_node_old ->
                if (null != item_node_old.get("imageURL")) {
                    def section_image_and_json_node = null
                    if (!source_page_content_node.hasNode("roomImages")) {
                        room_images_node = source_page_content_node.addNode("roomImages")
                        println room_images_node.path
                    } else {
                        room_images_node = source_page_content_node.getNode("roomImages")
                    }
                    def room_carousel_image_old = item_node_old.get("imageURL")
                    def item_node_name_new = "item" + no_of_carousel_images
                    def room_carousel_image = null
                    if(room_images_node.hasNode(item_node_name_new)){
                        room_carousel_image = room_images_node.getNode(item_node_name_new)
                    }else{
                        room_carousel_image = room_images_node.addNode(item_node_name_new)
                    }
                    room_carousel_image.set("roomImage", room_carousel_image_old)
                    println "Room Carousel Image " + no_of_carousel_images++ + " = " + room_carousel_image_old
                }
            }
        }
    }
}


    def setShipDetails(page) {
        def legacy_url = page.node.get("legacyUrl")
        println "Legacy URL = " + legacy_url
        if (null != legacy_url) {
            def master_website_page_path = getMasterWebSitePagePath(legacy_url)
            if (null != master_website_page_path) {
                def master_website_page = getPage(master_website_page_path)
                println "Master Website path : " + master_website_page_path
                if (null != master_website_page) {
                    def content = master_website_page.node
                    master_data_page_path = content.get("masterDataPath")
                    println "Master Data path = " + master_data_page_path
                    if (null != master_data_page_path) {
                        def master_data_page = getPage(master_data_page_path)
                        if (null != master_data_page) {
                            def master_data_content = master_data_page.node
                            // logic to set property names and call required method based on current page template
                            old_hero_image_property_name = "image"
                            old_long_description_property_name = "txLongDescription"
                            old_short_description_property_name = "txShortDescription"
                            new_hero_image_property_name = "image"
                            new_long_description_property_name = "longDescription"
                            new_short_description_property_name = "shortDescription"
                            master_data_child_node_name = "shipInfo"
                            setLongDescription(page.node, master_data_content)
                            setShortDescritpion(page.node, master_data_content)
                            setHeroImageURL(page.node, master_data_content)
                            setPDFDeckImages(page.node, master_data_content)
							setMediaGallery(page.node, master_data_content)
                        } else {
                            println "Couldn't retrieve Master Data Page / Master Data Page is null"
                        }
                    } else {
                        println "Master Data path not found."
                    }
                } else {
                    println "Couldn't retrieve Master Website Page / Master Website Page is null"
                }
            } else {
                println "Master Website path not found."
            }
        } else {
            println "Legacy URL not found."
        }
    }

    def setRoomDetails(page) {
        parent_ship_content_node = page.node.getNode("../../../jcr:content")
        def legacy_url = parent_ship_content_node.get("legacyUrl")
        println "Legacy URL = " + legacy_url
        if (null != legacy_url) {
            def master_website_page_path = getMasterWebSitePagePath(legacy_url)
            if (null != master_website_page_path) {
                def master_website_page = getPage(master_website_page_path)
                println "Master Website path : " + master_website_page_path
                if (null != master_website_page) {
                    def content = master_website_page.node
                    master_data_page_path = content.get("masterDataPath")
                    master_data_page_path = master_data_page_path + "/room-types/" + page.node.get("roomId")
                    println "Master Data path = " + master_data_page_path
                    if (null != master_data_page_path) {
                        def master_data_page = getPage(master_data_page_path)
                        if (null != master_data_page) {
                            def master_data_content = master_data_page.node
                            // logic to set property names and call required method based on current page template
                            old_hero_image_property_name = "roomImageURL"
                            old_long_description_property_name = "txLongDescription"
                            old_short_description_property_name = "txShortDescription"
                            new_hero_image_property_name = "image"
                            new_long_description_property_name = "longDescription"
                            new_short_description_property_name = "shortDescription"
                            master_data_child_node_name = "roomType"
                            setLongDescription(page.node, master_data_content)
                            setShortDescritpion(page.node, master_data_content)
                            setHeroImageURL(page.node, master_data_content)
                            setRoomCarousel(page.node, master_data_content)
                        } else {
                            println "Couldn't retrieve Master Data Page / Master Data Page is null"
                        }
                    } else {
                        println "Master Data path not found."
                    }
                } else {
                    println "Couldn't retrieve Master Website Page / Master Website Page is null"
                }
            } else {
                println "Master Website path not found."
            }
        } else {
            println "Legacy URL not found."
        }
    }

    def setSubRoomDetails(page) {
        parent_ship_content_node = page.node.getNode("../../../../jcr:content")
        def legacy_url = parent_ship_content_node.get("legacyUrl")
        println "Legacy URL = " + legacy_url
        if (null != legacy_url) {
            def master_website_page_path = getMasterWebSitePagePath(legacy_url)
            if (null != master_website_page_path) {
                def master_website_page = getPage(master_website_page_path)
                println "Master Website path : " + master_website_page_path
                if (null != master_website_page) {
                    def content = master_website_page.node
                    master_data_page_path = content.get("masterDataPath")
                    master_data_page_path = master_data_page_path + "/room-types/" + page.getParent().node.get("roomId") + "/" + page.node.get("categoryId")
                    println "Master Data path = " + master_data_page_path
                    if (null != master_data_page_path) {
                        def master_data_page = getPage(master_data_page_path)
                        if (null != master_data_page) {
                            def master_data_content = master_data_page.node
                            // logic to set property names and call required method based on current page template
                            old_hero_image_property_name = "marketRoomPrimaryImage"
                            old_long_description_property_name = "txLongDescription"
                            old_short_description_property_name = "txShortDescription"
                            new_hero_image_property_name = "image"
                            new_long_description_property_name = "longDescription"
                            new_short_description_property_name = "shortDescription"
                            master_data_child_node_name = "roomCategory"
                            setLongDescription(page.node, master_data_content)
                            setShortDescritpion(page.node, master_data_content)
                            setHeroImageURL(page.node, master_data_content)
                            setSubRoomCarousel(page.node, master_data_content)
                        } else {
                            println "Couldn't retrieve Master Data Page / Master Data Page is null"
                        }
                    } else {
                        println "Master Data path not found."
                    }
                } else {
                    println "Couldn't retrieve Master Website Page / Master Website Page is null"
                }
            } else {
                println "Master Website path not found."
            }
        } else {
            println "Legacy URL not found."
        }
    }

    def setDecksDetails(page) {
        parent_ship_content_node = page.node.getNode("../../jcr:content")
        def legacy_url = parent_ship_content_node.get("legacyUrl")
        println "Legacy URL = " + legacy_url
        if (null != legacy_url) {
            def master_website_page_path = getMasterWebSitePagePath(legacy_url)
            if (null != master_website_page_path) {
                def master_website_page = getPage(master_website_page_path)
                println "Master Website path : " + master_website_page_path
                if (null != master_website_page) {
                    def content = master_website_page.node
                    master_data_page_path = content.get("masterDataPath")
                    master_data_page_path = master_data_page_path + "/decks"
                    println "Master Data path = " + master_data_page_path
                    if (null != master_data_page_path) {
                        def master_data_page = getPage(master_data_page_path)
                        if (null != master_data_page) {
                            if (page.node.hasNode("root/container")) {
                                def source_page_deck_container_node = page.node.getNode("root/container")
                                master_data_page.recurse { deck_page ->
                                    master_data_page_content_node = deck_page.node
                                    if (master_data_page_content_node.hasNode("deckInfo")) {
                                        println "Deck Page in Old Content = " + deck_page.path
                                        deckInfo_node_old = master_data_page_content_node.getNode("deckInfo")
                                        def deck_id_old_content = deckInfo_node_old.get("id")
                                        for (Node deck_node_new : source_page_deck_container_node.nodes) {
                                            int deck_id_new_content = deck_node_new.get("deckId") as int
                                            if (deck_id_new_content == (int) deck_id_old_content) {
                                                println "Deck Page resource in new Content = " + deck_node_new.path
											def deckDetailsImage_old=deckInfo_node_old.get("deckDetailedImage")
											def image_old=deckInfo_node_old.get("image")
											deck_node_new.set("deckDetailedImageReference", deckDetailsImage_old)
											deck_node_new.set("deckImageReference", image_old)
											println "Deck Details Image = " + deckDetailsImage_old
											println "Image to Set = " + image_old
                                                if (deckInfo_node_old.hasNode("sectionImageAndJson") && deck_node_new.hasNode("sectionImageAndJson")) {
                                                    section_image_and_json_node_new = deck_node_new.getNode("sectionImageAndJson")
                                                    deckInfo_node_old.getNode("sectionImageAndJson").recurse { section_item_old ->
                                                        if (null != section_item_old.get("sectionId")) {
                                                            for (Node section_item_new : section_image_and_json_node_new.nodes) {
                                                                if (section_item_old.get("sectionId") == section_item_new.get("sectionId")) {
                                                                    println "Section Id to Set = " + section_item_old.get("sectionId")
                                                                    println "section Deck Image = " + section_item_old.get("deckImage")
                                                                    section_item_new.set("sectionImageReference", section_item_old.get("deckImage"))
                                                                    println "section Deck Json = " + section_item_old.get("deckJson")
                                                                    section_item_new.set("sectionJson", section_item_old.get("deckJson"))
                                                                    break
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                break
                                            }
                                        }
                                    }
                                }
                            } else {
                                println "Source Deck Pages doesn't have container node"
                            }
                        } else {
                            println "Couldn't retrieve Master Data Page / Master Data Page is null"
                        }
                    } else {
                        println "Master Data path not found."
                    }
                } else {
                    println "Couldn't retrieve Master Website Page / Master Website Page is null"
                }
            } else {
                println "Master Website path not found."
            }
        } else {
            println "Legacy URL not found."
        }
    }


// counter indicates total number of pages traversed by script during the run (includes all pages with different templates under source root path)
    println "total number of pages traversed : " + no_of_source_pages





