import com.day.cq.dam.api.AssetManager
import java.text.SimpleDateFormat
import org.apache.poi.hssf.usermodel.*
import org.apache.poi.hssf.util.*
import org.apache.poi.ss.usermodel.*
import org.apache.commons.lang3.StringUtils
// Script to add Long description , Short description and HERO Image URL to feed pages by reading properties from old content

// Root Path of Feed pages to run the migration

source_page_path = "/content/hal/global/en"

// List of templates to consider for migration
country_details_template = "/conf/hal/settings/wcm/templates/country-details-template"
destination_details_template = "/conf/hal/settings/wcm/templates/destination-details-template"
cruise_details_template = "/conf/hal/settings/wcm/templates/cruise-details-template"
port_details_template = "/conf/hal/settings/wcm/templates/port-details-template"
excursion_details_template = "/conf/hal/settings/wcm/templates/excursion-details-template"


list_of_templates = [country_details_template, destination_details_template, cruise_details_template, port_details_template, excursion_details_template]

// JCR property names declarations old - 6.4 site and new 6.5 site

old_hero_image_property_name = ""
old_long_description_property_name = ""
old_short_description_property_name = ""
old_map_image_property_name=""
new_hero_image_property_name = ""
new_long_description_property_name = ""
new_short_description_property_name = ""
master_data_child_node_name = ""
new_map_image_property_name=""


// counter variables
// counter for to count overall pages traversed during the migration
no_of_source_pages = 0
rowNum = 1
sl_no_col_num = 0
page_path_col_num = 1
page_template_col_num = 2
legacy_url_col_num = 3
master_website_path_col_num = 4
master_data_path_col_num = 5
long_description_col_num = 6
short_description_col_num = 7
hero_image_col_num = 8
map_image_col_num=9

// definitions for Reporting Excel Sheet Start - this excel sheet is for reporting purpose (contains details of migration)

HSSFWorkbook workbook = new HSSFWorkbook()
sheet = workbook.createSheet("Sheet 1")

header_style = workbook.createCellStyle()
header_font = workbook.createFont()
header_font.setBold(true)
header_style.setFont(header_font)
header_style.setAlignment(HorizontalAlignment.CENTER)

error_style = workbook.createCellStyle()
error_font = workbook.createFont()
error_font.setColor(IndexedColors.RED.getIndex())
error_style.setFont(error_font)

createExcelHeader(sheet, header_style)

// definitions for Reporting Excel Sheet Ends


updateAllSourcePages()

def updateAllSourcePages() {
    getPage(source_page_path).recurse { page ->
        println "------------------- START -------------------------"
        row = sheet.createRow((short) (rowNum))
        def colCount = 0
        row.createCell(sl_no_col_num).setCellValue(rowNum)
        println "Curent Page Path = " + page.path
        row.createCell(page_path_col_num).setCellValue(page.path)
        def source_page_content_node = page.node
        current_page_template = source_page_content_node.get("cq:template")
        row.createCell(page_template_col_num).setCellValue(current_page_template)
        println "Curent Page Template = " + current_page_template
        if (list_of_templates.contains(current_page_template)) {
            def legacy_url = source_page_content_node.get("legacyUrl")
            row.createCell(legacy_url_col_num).setCellValue(legacy_url)
            println "Legacy URL = " + legacy_url
            if (null != legacy_url) {		
                def master_website_page_path =""
				if(current_page_template.equals(cruise_details_template))
				{ 
				  master_website_page_path = getCruiseMasterWebSitePagePath(legacy_url)
				}
				else{
				 master_website_page_path = getMasterWebSitePagePath(legacy_url)
				}
                if (null != master_website_page_path) {
                    def master_website_page = getPage(master_website_page_path)
                    row.createCell(master_website_path_col_num).setCellValue(master_website_page_path)
                    println "Master Website path : " + master_website_page_path
                    if (null != master_website_page) {
                        def content = master_website_page.node
                        master_data_page_path = content.get("masterDataPath")
                        row.createCell(master_data_path_col_num).setCellValue(master_data_page_path)
                        println "Master Data path = " + master_data_page_path
                        if (null != master_data_page_path) {
                            def master_data_page = getPage(master_data_page_path)
                            if (null != master_data_page) {
                                def master_data_content = master_data_page.node
                                // logic to set property names and call required method based on current page template
                                switch (current_page_template) {							
                                    case country_details_template:
                                        old_hero_image_property_name = "primaryImage"
                                        old_long_description_property_name = "txLongDescription"
                                        old_short_description_property_name = "txShortDescription"
                                        new_hero_image_property_name = "image"
                                        new_long_description_property_name = "longDescription"
                                        new_short_description_property_name = "shortDescription"
                                        master_data_child_node_name = "countryDetails"
                                        setLongDescription(source_page_content_node, master_data_content, current_page_template, row)
                                        setShortDescritpion(source_page_content_node, master_data_content, current_page_template, row)
                                        setHeroImageURL(source_page_content_node, master_data_content, current_page_template, row)
                                        break
                                    case destination_details_template:
                                        old_hero_image_property_name = "primaryImage"
                                        old_long_description_property_name = "txLongDescription"
                                        old_short_description_property_name = "txShortDescription"
                                        new_hero_image_property_name = "image"
                                        new_long_description_property_name = "longDescription"
                                        new_short_description_property_name = "shortDescription"
                                        master_data_child_node_name = "destinationDetails"
                                        setLongDescription(source_page_content_node, master_data_content, current_page_template, row)
                                        setShortDescritpion(source_page_content_node, master_data_content, current_page_template, row)
                                        setHeroImageURL(source_page_content_node, master_data_content, current_page_template, row)
                                        break
                                    case cruise_details_template:
                                        old_hero_image_property_name = "overviewImage"
                                        old_long_description_property_name = "txDescription"
									    old_map_image_property_name = "itineraryMapImage"
                                        new_hero_image_property_name = "image"
                                        new_long_description_property_name = "description"
									    new_map_image_property_name = "mapImage"
                                        master_data_child_node_name = "cruise"
                                        setLongDescription(source_page_content_node, master_data_content, current_page_template, row)
                                        setHeroImageURL(source_page_content_node, master_data_content, current_page_template, row)
									    setMapImage(source_page_content_node, master_data_content, current_page_template, row)
                                        break
                                    case port_details_template:
                                        old_hero_image_property_name = "overviewImage"
                                        old_long_description_property_name = "txLongDescription"
                                        old_short_description_property_name = "txShortDescription"
                                        new_hero_image_property_name = "image"
                                        new_long_description_property_name = "longDescription"
                                        new_short_description_property_name = "shortDescription"
                                        master_data_child_node_name = "portDetails"
                                        setLongDescription(source_page_content_node, master_data_content, current_page_template, row)
                                        setShortDescritpion(source_page_content_node, master_data_content, current_page_template, row)
                                        setHeroImageURL(source_page_content_node, master_data_content, current_page_template, row)
                                        break
                                    case excursion_details_template:
                                        old_hero_image_property_name = "overviewImage"
                                        new_hero_image_property_name = "overviewImage"
                                        master_data_child_node_name = "excursionParent"
                                        colCount = colCount + 2
                                        setHeroImageURL(source_page_content_node, master_data_content, current_page_template, row)
                                        break
                                    default:
                                        println "template not matched in switch case"
                                        break
                                }
                                session.save()
                            } else {
                                createErrorCell(row, master_data_path_col_num, "Couldn't retrieve Master Data Page / Master Data Page is null")
                                println "Couldn't retrieve Master Data Page / Master Data Page is null"
                            }
                        } else {
                            createErrorCell(row, master_website_path_col_num, "Master Data path not found.")
                            println "Master Data path not found."
                        }
                    } else {
                        createErrorCell(row, master_website_path_col_num, "Couldn't retrieve Master Website Page / Master Website Page is null")
                        println "Couldn't retrieve Master Website Page / Master Website Page is null"
                    }
                } else {
                    createErrorCell(row, master_website_path_col_num, "Master Website path not found.")
                    println "Master Website path not found."
                }
            } else {
                createErrorCell(row, legacy_url_col_num, "Legacy URL not found.")
                println "Legacy URL not found."
            }
        } else {
            createErrorCell(row, page_template_col_num, "Template doesn't match with the defined list")
            println "Template doesn't match with the defined list"
        }
        println "------------------- END -------------------------"
        rowNum++
        no_of_source_pages++
    }

}

// this style will be used to highlight error messages in reporting sheet
def createErrorCell(row, int col_count, error_message) {
    cell = row.createCell(col_count + 1)
    cell.setCellStyle(error_style)
    cell.setCellValue(error_message)
}


// this method sets hero image property on the 6.5 site page
def setHeroImageURL(source_page_content_node, master_data_content, current_page_template, row) {
    def hero_image_url = ""
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        hero_image_url = child_node.get(old_hero_image_property_name)
        source_page_content_node.set(new_hero_image_property_name, hero_image_url)
        if (source_page_content_node.hasNode("root/container/hero")) {
            hero_node = source_page_content_node.getNode("root/container/hero")
            hero_node.set("heroType", "port")
        }
    }
    println "Hero Image URL in old content = " + hero_image_url
    row.createCell(hero_image_col_num).setCellValue(hero_image_url)

}

// this method sets short description  property on the 6.5 site page
def setShortDescritpion(source_page_content_node, master_data_content, current_page_template, row) {
    def short_description = "";
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        short_description = child_node.get("txShortDescription")
        source_page_content_node.set("shortDescription", short_description)
    }
    println "Short Description in old content = " + short_description
    row.createCell(short_description_col_num).setCellValue(short_description)

}

// this method sets long description  property on the 6.5 site page
def setLongDescription(source_page_content_node, master_data_content, current_page_template, row) {
    def long_description = "";
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        long_description = child_node.get(old_long_description_property_name)
        source_page_content_node.set(new_long_description_property_name, long_description)
    }
    println "Long Description in old content = " + long_description
    row.createCell(long_description_col_num).setCellValue(long_description)

}
// this method sets itineraryMapImage property on the 6.5 site cruise page
def setMapImage(source_page_content_node, master_data_content, current_page_template, row) {
    def map_image = "";
    if (master_data_content.hasNode(master_data_child_node_name)) {
        def child_node = master_data_content.getNode(master_data_child_node_name)
        map_image = child_node.get(old_map_image_property_name)
        source_page_content_node.set(new_map_image_property_name, map_image)
    }
    println "Itinerary Map Image in old content = " + map_image
    row.createCell(map_image_col_num).setCellValue(map_image)

}

// this method fetches 6.4 website content path using the legacy URL property in 6.5 content page
def getMasterWebSitePagePath(legacy_full_url) {
    def master_content_root_path = "/content/hal/master_website"
    def master_website_page_path = legacy_full_url.replace("https://www.hollandamerica.com", "")
    master_website_page_path = master_website_page_path.replace(".html", "")
    master_website_page_path = master_content_root_path + master_website_page_path
    return master_website_page_path
}

// this method fetches 6.4 cruise website content path using the legacy URL property in 6.5 content page
def getCruiseMasterWebSitePagePath(legacy_full_url) {
    def master_content_root_path = "/content/hal/master_website"
    def master_website_page_path = legacy_full_url.replace("https://www.hollandamerica.com", "")
    master_website_page_path = master_website_page_path.replace(".html", "")
	def master_website_page_path_list=[]
	 master_website_page_path_list=master_website_page_path.split("find-a-cruise/");
	master_website_page_path=master_website_page_path_list[0]+"find-a-cruise/"+master_website_page_path_list[1].toUpperCase()
    master_website_page_path = master_content_root_path + master_website_page_path
    return master_website_page_path
}

// counter indicates total number of pages traversed by script during the run (includes all pages with different templates under source root path)
println "total number of pages traversed : " + no_of_source_pages


createDamFileForExcel(workbook)

// method to create report excel file (asset) in dam under /content/dam/groovy/output/
def createDamFileForExcel(def workbook) {
    Date date = new Date()
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy'T'HH-mm-ss")
    def dateTimeString = dateFormat.format(date)
    def filename = "Report_" + dateTimeString + ".xls"
    def baos = new ByteArrayOutputStream()
    workbook.write(baos)
    def location = "/content/dam/groovy/output/"
    def bais = new ByteArrayInputStream(baos.toByteArray())
    assetManager = resourceResolver.adaptTo(AssetManager)
    def asset = assetManager.createAsset(location + filename, bais, "application/vnd.ms-excel", true)
    bais.close()
    baos.close()
    location + filename
}

// creation of header values in reporting sheet
def createExcelHeader(sheet, header_style) {
    HSSFRow rowhead = sheet.createRow(0)

    def columnCount = 0

    Cell cell = rowhead.createCell(columnCount++)
    cell.setCellValue("SL No.")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Page path")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Page Template")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Legacy URL")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Master Website path")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Master Data path")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Long Description in old content")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Short Description in old content")
    cell.setCellStyle(header_style)

    cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Hero Image URL in old content")
    cell.setCellStyle(header_style)
	
	 cell = rowhead.createCell(columnCount++)
    cell.setCellValue("Map Image URL in old content")
    cell.setCellStyle(header_style)


    sheet.setColumnWidth(sl_no_col_num, 256 * 10)
    sheet.setColumnWidth(page_path_col_num, 256 * 30)
    sheet.setColumnWidth(page_template_col_num, 256 * 30)
    sheet.setColumnWidth(legacy_url_col_num, 256 * 30)
    sheet.setColumnWidth(master_website_path_col_num, 256 * 30)
    sheet.setColumnWidth(master_data_path_col_num, 256 * 30)
    sheet.setColumnWidth(long_description_col_num, 256 * 30)
    sheet.setColumnWidth(short_description_col_num, 256 * 30)
    sheet.setColumnWidth(hero_image_col_num, 256 * 30)
	sheet.setColumnWidth(map_image_col_num, 256 * 30)
}
